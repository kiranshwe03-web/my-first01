# Auth Testing Playbook — Shubharambha Constructions

Admin auth: email/password -> JWT Bearer token (12h expiry). Token stored in localStorage key `sc_admin_token`, sent as `Authorization: Bearer <token>`.

## Step 1: MongoDB Verification
```
mongosh
use test_database
db.users.find({role: "admin"}).pretty()
```
Verify: bcrypt hash starts with `$2b$`.

## Step 2: API Testing
```
API_URL=$(grep REACT_APP_BACKEND_URL /app/frontend/.env | cut -d '=' -f2)
TOKEN=$(curl -s -X POST "$API_URL/api/auth/login" -H "Content-Type: application/json" \
  -d '{"email":"admin@shubharambhaconstructions.co.in","password":"Shubharambha@2026"}' \
  | python3 -c "import sys,json;print(json.load(sys.stdin)['access_token'])")
curl -s "$API_URL/api/auth/me" -H "Authorization: Bearer $TOKEN"
curl -s "$API_URL/api/enquiries" -H "Authorization: Bearer $TOKEN"
curl -s "$API_URL/api/enquiries/stats" -H "Authorization: Bearer $TOKEN"
```
Expected: login returns access_token; /me returns admin object; enquiries list + stats return data. Wrong password -> 401.
