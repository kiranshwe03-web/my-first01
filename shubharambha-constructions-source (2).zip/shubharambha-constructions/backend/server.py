from pathlib import Path
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / ".env")

import logging
import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import List, Optional

import bcrypt
import jwt
from fastapi import APIRouter, Depends, FastAPI, HTTPException, Query
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field
from starlette.middleware.cors import CORSMiddleware

mongo_url = os.environ["MONGO_URL"]
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ["DB_NAME"]]

JWT_SECRET = os.environ["JWT_SECRET"]
JWT_ALGORITHM = "HS256"
ADMIN_EMAIL = os.environ["ADMIN_EMAIL"].lower()
ADMIN_PASSWORD = os.environ["ADMIN_PASSWORD"]

app = FastAPI()
api_router = APIRouter(prefix="/api")
security = HTTPBearer(auto_error=False)

logger = logging.getLogger("shubharambha")
logging.basicConfig(level=logging.INFO)


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))


def create_token(email: str) -> str:
    payload = {
        "sub": email,
        "role": "admin",
        "exp": datetime.now(timezone.utc) + timedelta(hours=12),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


async def get_current_admin(
    credentials: HTTPAuthorizationCredentials = Depends(security),
):
    if not credentials:
        raise HTTPException(status_code=401, detail="Not authenticated")
    try:
        payload = jwt.decode(credentials.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    if payload.get("sub") != ADMIN_EMAIL:
        raise HTTPException(status_code=401, detail="Invalid token")
    return {"email": payload["sub"], "role": "admin"}


class LoginInput(BaseModel):
    email: str
    password: str


class EnquiryCreate(BaseModel):
    name: str
    phone: str
    email: Optional[str] = None
    project_type: str = "Residential"
    plot_location: str = ""
    plot_size: str = ""
    built_up_area: Optional[int] = None
    package: str = "Premium"
    timeline: str = ""
    site_status: str = ""
    budget: str = ""
    requirements: str = ""
    estimated_cost: Optional[float] = None


class Enquiry(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    phone: str
    email: Optional[str] = None
    project_type: str
    plot_location: str
    plot_size: str
    built_up_area: Optional[int] = None
    package: str
    timeline: str
    site_status: str
    budget: str
    requirements: str
    estimated_cost: Optional[float] = None
    status: str = "new"
    created_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


class StatusUpdate(BaseModel):
    status: str


@api_router.get("/")
async def root():
    return {"message": "Shubharambha Constructions API"}


@api_router.post("/auth/login")
async def login(input: LoginInput):
    email = input.email.lower().strip()
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(input.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Access denied")
    token = create_token(email)
    return {"access_token": token, "user": {"email": email, "role": "admin"}}


@api_router.get("/auth/me")
async def me(admin=Depends(get_current_admin)):
    return admin


@api_router.post("/enquiries")
async def create_enquiry(input: EnquiryCreate):
    enquiry = Enquiry(**input.model_dump())
    doc = enquiry.model_dump()
    await db.enquiries.insert_one(doc)
    logger.info(f"New enquiry from {enquiry.name} ({enquiry.phone}) package={enquiry.package}")
    return enquiry.model_dump()


@api_router.get("/enquiries")
async def list_enquiries(
    status: Optional[str] = Query(default=None),
    admin=Depends(get_current_admin),
):
    query = {"status": status} if status else {}
    docs = await db.enquiries.find(query, {"_id": 0}).sort("created_at", -1).to_list(1000)
    return docs


@api_router.get("/enquiries/stats")
async def enquiry_stats(admin=Depends(get_current_admin)):
    docs = await db.enquiries.find({}, {"_id": 0}).to_list(5000)
    by_status = {}
    by_package = {}
    for d in docs:
        by_status[d["status"]] = by_status.get(d["status"], 0) + 1
        by_package[d["package"]] = by_package.get(d["package"], 0) + 1
    return {
        "total": len(docs),
        "new": by_status.get("new", 0),
        "by_status": by_status,
        "by_package": by_package,
    }


@api_router.patch("/enquiries/{enquiry_id}")
async def update_enquiry_status(
    enquiry_id: str, input: StatusUpdate, admin=Depends(get_current_admin)
):
    result = await db.enquiries.update_one(
        {"id": enquiry_id}, {"$set": {"status": input.status}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Enquiry not found")
    doc = await db.enquiries.find_one({"id": enquiry_id}, {"_id": 0})
    return doc


@api_router.delete("/enquiries/{enquiry_id}")
async def delete_enquiry(enquiry_id: str, admin=Depends(get_current_admin)):
    result = await db.enquiries.delete_one({"id": enquiry_id})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Enquiry not found")
    return {"deleted": True}


app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    existing = await db.users.find_one({"email": ADMIN_EMAIL})
    if existing is None:
        await db.users.insert_one(
            {
                "email": ADMIN_EMAIL,
                "password_hash": hash_password(ADMIN_PASSWORD),
                "name": "Admin",
                "role": "admin",
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
        )
        logger.info(f"Seeded admin {ADMIN_EMAIL}")
    elif not verify_password(ADMIN_PASSWORD, existing["password_hash"]):
        await db.users.update_one(
            {"email": ADMIN_EMAIL},
            {"$set": {"password_hash": hash_password(ADMIN_PASSWORD)}},
        )
    await db.enquiries.create_index("created_at")


@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
