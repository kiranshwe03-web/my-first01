import { useState } from "react";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Marquee from "@/components/Marquee";
import Packages from "@/components/Packages";
import Services from "@/components/Services";
import Estimator from "@/components/Estimator";
import About from "@/components/About";
import Reviews from "@/components/Reviews";
import EnquiryForm from "@/components/EnquiryForm";
import Contact, { Footer } from "@/components/Contact";

export default function Landing() {
  const [prefill, setPrefill] = useState(null);

  const goToEnquiry = (data) => {
    setPrefill({ ...(data || {}), _t: Date.now() });
    document.getElementById("enquire")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="relative" data-testid="landing-page">
      <div className="grain-overlay" />
      <Navbar />
      <Hero />
      <Marquee />
      <Packages onSelect={(id) => goToEnquiry({ package: id })} />
      <Services />
      <Estimator onLockEstimate={goToEnquiry} />
      <About />
      <Reviews />
      <EnquiryForm prefill={prefill} />
      <Contact />
      <Footer />
    </div>
  );
}
