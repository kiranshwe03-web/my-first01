import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { HardHat, Loader2, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import api, { formatApiError } from "@/lib/api";

export default function AdminLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post("/auth/login", { email, password });
      localStorage.setItem("sc_admin_token", data.access_token);
      toast.success("Welcome back, Admin.");
      navigate("/admin");
    } catch (err) {
      toast.error(formatApiError(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#07080A] flex items-center justify-center px-5 relative overflow-hidden">
      <div className="absolute inset-0 blueprint-grid opacity-50" />
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-10 w-full max-w-md rounded-xl border border-white/10 bg-[#0D0F14] p-8 sm:p-10 shadow-[0_0_80px_rgba(245,158,11,0.08)]"
        data-testid="admin-login-card"
      >
        <div className="flex items-center gap-3">
          <span className="w-11 h-11 grid place-items-center rounded-md bg-amber-400 text-black">
            <HardHat size={22} />
          </span>
          <div>
            <h1 className="font-syne font-extrabold uppercase text-xl text-white">Command Center</h1>
            <p className="font-jbmono text-[10px] uppercase tracking-[0.3em] text-amber-400/80">
              Shubharambha Admin
            </p>
          </div>
        </div>

        <form onSubmit={submit} className="mt-8 space-y-5">
          <div>
            <label className="block font-jbmono text-[11px] uppercase tracking-[0.2em] text-zinc-400 mb-2">
              Admin Email
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              data-testid="admin-login-username"
              placeholder="admin@shubharambhaconstructions.co.in"
              className="w-full bg-[#10131A] border border-white/10 rounded-md px-4 py-3 text-sm text-white placeholder-zinc-600 focus:outline-none focus:border-amber-400/60 focus:ring-1 focus:ring-amber-400/40 transition-all"
            />
          </div>
          <div>
            <label className="block font-jbmono text-[11px] uppercase tracking-[0.2em] text-zinc-400 mb-2">
              Password
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              data-testid="admin-login-password"
              placeholder="••••••••••"
              className="w-full bg-[#10131A] border border-white/10 rounded-md px-4 py-3 text-sm text-white placeholder-zinc-600 focus:outline-none focus:border-amber-400/60 focus:ring-1 focus:ring-amber-400/40 transition-all"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            data-testid="admin-login-submit"
            className="w-full inline-flex items-center justify-center gap-2 bg-amber-400 text-black font-syne font-bold uppercase tracking-wide text-sm py-3.5 rounded-md hover:shadow-[0_0_30px_rgba(245,158,11,0.5)] transition-all duration-300 disabled:opacity-60"
          >
            {loading ? <Loader2 size={16} className="animate-spin" /> : null}
            {loading ? "Verifying…" : "Enter Dashboard"}
          </button>
        </form>

        <Link
          to="/"
          data-testid="admin-login-back-link"
          className="mt-6 inline-flex items-center gap-1.5 text-xs font-jbmono uppercase tracking-[0.2em] text-zinc-500 hover:text-amber-400 transition-colors"
        >
          <ArrowLeft size={13} /> Back to website
        </Link>
      </motion.div>
    </div>
  );
}
