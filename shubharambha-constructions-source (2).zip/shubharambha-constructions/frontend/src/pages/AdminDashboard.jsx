import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  HardHat, LogOut, RefreshCw, Download, Search, Inbox, Bell, Trash2,
} from "lucide-react";
import { toast } from "sonner";
import api from "@/lib/api";
import { STATUSES } from "@/lib/data";

const STATUS_COLORS = {
  new: "text-amber-400 border-amber-400/40 bg-amber-400/10",
  contacted: "text-cyan-400 border-cyan-400/40 bg-cyan-400/10",
  "site-visit": "text-violet-400 border-violet-400/40 bg-violet-400/10",
  "estimate-sent": "text-emerald-400 border-emerald-400/40 bg-emerald-400/10",
  closed: "text-zinc-400 border-zinc-500/40 bg-zinc-500/10",
};

export default function AdminDashboard() {
  const [enquiries, setEnquiries] = useState([]);
  const [stats, setStats] = useState(null);
  const [statusFilter, setStatusFilter] = useState("");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  const load = useCallback(async () => {
    try {
      const [list, st] = await Promise.all([
        api.get("/enquiries"),
        api.get("/enquiries/stats"),
      ]);
      setEnquiries(list.data);
      setStats(st.data);
    } catch (err) {
      if (err?.response?.status === 401) {
        localStorage.removeItem("sc_admin_token");
        navigate("/admin/login");
      } else {
        toast.error("Failed to load enquiries.");
      }
    } finally {
      setLoading(false);
    }
  }, [navigate]);

  useEffect(() => {
    if (!localStorage.getItem("sc_admin_token")) {
      navigate("/admin/login");
      return;
    }
    load();
  }, [load, navigate]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return enquiries.filter(
      (e) =>
        (!statusFilter || e.status === statusFilter) &&
        (!q ||
          [e.name, e.phone, e.email, e.plot_location, e.package]
            .filter(Boolean)
            .some((v) => v.toLowerCase().includes(q)))
    );
  }, [enquiries, statusFilter, search]);

  const updateStatus = async (id, status) => {
    try {
      const { data } = await api.patch(`/enquiries/${id}`, { status });
      setEnquiries((list) => list.map((e) => (e.id === id ? data : e)));
      toast.success(`Marked as ${STATUSES.find((s) => s.id === status)?.label}`);
    } catch {
      toast.error("Could not update status.");
    }
  };

  const remove = async (id) => {
    try {
      await api.delete(`/enquiries/${id}`);
      setEnquiries((list) => list.filter((e) => e.id !== id));
      toast.success("Enquiry deleted.");
    } catch {
      toast.error("Could not delete enquiry.");
    }
  };

  const exportCsv = () => {
    const rows = [
      ["Name", "Phone", "Email", "Project Type", "Package", "Plot Location", "Plot Size", "Built-up Area", "Timeline", "Budget", "Status", "Requirements", "Created At"],
      ...filtered.map((e) => [
        e.name, e.phone, e.email, e.project_type, e.package, e.plot_location,
        e.plot_size, e.built_up_area, e.timeline, e.budget, e.status, e.requirements, e.created_at,
      ]),
    ];
    const csv = rows
      .map((r) => r.map((v) => `"${String(v ?? "").replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "shubharambha-enquiries.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const logout = () => {
    localStorage.removeItem("sc_admin_token");
    navigate("/admin/login");
  };

  return (
    <div className="min-h-screen bg-[#07080A]" data-testid="admin-dashboard">
      <header className="sticky top-0 z-40 bg-black/80 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5" data-testid="admin-brand">
            <span className="w-9 h-9 grid place-items-center rounded-md bg-amber-400 text-black">
              <HardHat size={19} />
            </span>
            <span className="font-syne font-bold uppercase tracking-tight text-sm text-white">
              Shubharambha
              <span className="block text-[10px] font-jbmono tracking-[0.3em] text-amber-400/80">
                Command Center
              </span>
            </span>
          </Link>
          <div className="flex items-center gap-2.5">
            {stats?.new > 0 && (
              <span
                data-testid="admin-new-badge"
                className="inline-flex items-center gap-1.5 text-xs font-jbmono uppercase tracking-wider text-amber-400 border border-amber-400/40 bg-amber-400/10 rounded-full px-3.5 py-1.5"
              >
                <Bell size={12} /> {stats.new} new
              </span>
            )}
            <button
              onClick={load}
              data-testid="admin-refresh-btn"
              className="grid place-items-center w-9 h-9 rounded-md border border-white/15 text-zinc-400 hover:text-amber-400 hover:border-amber-400/40 transition-colors"
              aria-label="Refresh"
            >
              <RefreshCw size={15} />
            </button>
            <button
              onClick={logout}
              data-testid="admin-logout-btn"
              className="inline-flex items-center gap-1.5 text-xs font-jbmono uppercase tracking-wider text-zinc-400 border border-white/15 rounded-md px-3.5 py-2 hover:text-red-400 hover:border-red-400/40 transition-colors"
            >
              <LogOut size={13} /> Logout
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-5 sm:px-8 py-10">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: "Total Enquiries", value: stats?.total ?? "—", testid: "admin-stat-total" },
            { label: "New Leads", value: stats?.new ?? "—", testid: "admin-stat-new" },
            { label: "Premium Package", value: stats?.by_package?.Premium ?? 0, testid: "admin-stat-premium" },
            { label: "Elite Package", value: stats?.by_package?.Elite ?? 0, testid: "admin-stat-elite" },
          ].map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: i * 0.07 }}
              data-testid={s.testid}
              className="rounded-xl border border-white/10 bg-[#0D0F14] p-5"
            >
              <p className="font-jbmono text-[10px] uppercase tracking-[0.25em] text-zinc-500">{s.label}</p>
              <p className="mt-2 font-syne font-extrabold text-3xl text-white">{s.value}</p>
            </motion.div>
          ))}
        </div>

        <div className="mt-8 flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[220px]">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              data-testid="admin-search-input"
              placeholder="Search name, phone, location, package…"
              className="w-full bg-[#10131A] border border-white/10 rounded-md pl-10 pr-4 py-2.5 text-sm text-white placeholder-zinc-600 focus:outline-none focus:border-amber-400/50 transition-colors"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            data-testid="admin-status-filter"
            className="bg-[#10131A] border border-white/10 rounded-md px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400/50"
          >
            <option value="">All statuses</option>
            {STATUSES.map((s) => (
              <option key={s.id} value={s.id}>{s.label}</option>
            ))}
          </select>
          <button
            onClick={exportCsv}
            data-testid="admin-export-csv-btn"
            className="inline-flex items-center gap-2 text-xs font-jbmono uppercase tracking-wider text-black bg-amber-400 rounded-md px-4 py-2.5 hover:shadow-[0_0_20px_rgba(245,158,11,0.4)] transition-shadow"
          >
            <Download size={14} /> Export CSV
          </button>
        </div>

        <div className="mt-6 rounded-xl border border-white/10 bg-[#0D0F14] overflow-hidden">
          {loading ? (
            <div className="p-16 text-center text-zinc-500 font-jbmono text-sm uppercase tracking-[0.25em]">
              Loading enquiries…
            </div>
          ) : filtered.length === 0 ? (
            <div className="p-16 text-center" data-testid="admin-empty-state">
              <Inbox size={34} className="mx-auto text-zinc-600" />
              <p className="mt-4 font-jbmono text-sm uppercase tracking-[0.25em] text-zinc-500">
                No enquiries yet — new client requests will appear here instantly.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/10 text-left font-jbmono text-[10px] uppercase tracking-[0.2em] text-zinc-500">
                    <th className="px-5 py-4">Client</th>
                    <th className="px-5 py-4">Project</th>
                    <th className="px-5 py-4">Plot / Area</th>
                    <th className="px-5 py-4">Package</th>
                    <th className="px-5 py-4">Received</th>
                    <th className="px-5 py-4">Status</th>
                    <th className="px-5 py-4" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {filtered.map((e) => (
                    <tr key={e.id} data-testid="admin-enquiry-row" className="hover:bg-white/[0.03] transition-colors align-top">
                      <td className="px-5 py-4">
                        <p className="font-syne font-bold text-white">{e.name}</p>
                        <a href={`tel:+91${e.phone}`} className="text-amber-400/90 hover:text-amber-400 font-jbmono text-xs">
                          {e.phone}
                        </a>
                        {e.email && <p className="text-zinc-500 text-xs mt-0.5">{e.email}</p>}
                        {e.requirements && (
                          <p className="text-zinc-500 text-xs mt-1.5 max-w-[240px] line-clamp-2">{e.requirements}</p>
                        )}
                      </td>
                      <td className="px-5 py-4 text-zinc-300">
                        {e.project_type}
                        {e.timeline && <p className="text-zinc-500 text-xs mt-0.5">{e.timeline}</p>}
                        {e.budget && <p className="text-zinc-500 text-xs">{e.budget}</p>}
                      </td>
                      <td className="px-5 py-4 text-zinc-300">
                        {e.plot_location || "—"}
                        <p className="text-zinc-500 text-xs mt-0.5">
                          {[e.plot_size, e.built_up_area ? `${e.built_up_area} sq.ft` : ""].filter(Boolean).join(" · ") || "—"}
                        </p>
                      </td>
                      <td className="px-5 py-4">
                        <span className="font-jbmono text-xs text-amber-400">{e.package}</span>
                        {e.estimated_cost && (
                          <p className="text-zinc-500 text-xs mt-0.5">
                            ~₹{Number(e.estimated_cost).toLocaleString("en-IN")}
                          </p>
                        )}
                      </td>
                      <td className="px-5 py-4 font-jbmono text-xs text-zinc-500 whitespace-nowrap">
                        {new Date(e.created_at).toLocaleString("en-IN", {
                          day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit",
                        })}
                      </td>
                      <td className="px-5 py-4">
                        <select
                          value={e.status}
                          onChange={(ev) => updateStatus(e.id, ev.target.value)}
                          data-testid="admin-status-select"
                          className={`border rounded-full px-3 py-1.5 text-xs font-jbmono uppercase tracking-wider bg-transparent focus:outline-none cursor-pointer ${STATUS_COLORS[e.status] || STATUS_COLORS.new}`}
                        >
                          {STATUSES.map((s) => (
                            <option key={s.id} value={s.id} className="bg-[#0D0F14] text-white">
                              {s.label}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="px-5 py-4">
                        <button
                          onClick={() => remove(e.id)}
                          data-testid="admin-delete-btn"
                          aria-label="Delete enquiry"
                          className="text-zinc-600 hover:text-red-400 transition-colors"
                        >
                          <Trash2 size={15} />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
