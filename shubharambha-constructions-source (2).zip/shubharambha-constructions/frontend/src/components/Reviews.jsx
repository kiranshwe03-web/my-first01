import { motion } from "framer-motion";
import { Star, BadgeCheck, Quote } from "lucide-react";
import { REVIEWS } from "@/lib/data";

export default function Reviews() {
  return (
    <section id="reviews" className="relative py-24 sm:py-32">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl"
        >
          <p className="font-jbmono text-xs uppercase tracking-[0.35em] text-amber-400">
            Client Voices
          </p>
          <h2 className="mt-3 font-syne font-extrabold uppercase tracking-tight text-3xl sm:text-5xl text-white">
            Mysore Speaks.
            <span className="block text-zinc-500">We Listen, Then We Build.</span>
          </h2>
        </motion.div>

        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {REVIEWS.map((r, i) => (
            <motion.figure
              key={r.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.7, delay: (i % 3) * 0.1 }}
              data-testid={`review-card-${i}`}
              className="relative rounded-xl border border-white/10 bg-[#0D0F14] p-7 hover:border-amber-400/40 hover:shadow-[0_0_40px_rgba(245,158,11,0.12)] transition-all duration-500"
            >
              <Quote size={26} className="text-amber-400/40" />
              <div className="mt-3 flex gap-1">
                {Array.from({ length: r.stars }).map((_, s) => (
                  <Star key={s} size={14} className="fill-amber-400 text-amber-400" />
                ))}
              </div>
              <blockquote className="mt-4 text-sm sm:text-base text-zinc-300 leading-relaxed">
                "{r.text}"
              </blockquote>
              <figcaption className="mt-6 pt-5 border-t border-white/10">
                <div className="flex items-center gap-2">
                  <p className="font-syne font-bold text-white">{r.name}</p>
                  <BadgeCheck size={15} className="text-emerald-400" />
                </div>
                <p className="font-jbmono text-[11px] uppercase tracking-[0.15em] text-zinc-500 mt-1">
                  {r.place}
                </p>
                <p className="font-jbmono text-[11px] uppercase tracking-[0.15em] text-amber-400/80 mt-0.5">
                  {r.project}
                </p>
              </figcaption>
            </motion.figure>
          ))}
        </div>
      </div>
    </section>
  );
}
