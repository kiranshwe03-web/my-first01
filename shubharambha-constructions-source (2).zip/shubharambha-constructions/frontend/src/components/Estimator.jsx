import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { IndianRupee, Clock, Lock } from "lucide-react";
import { PACKAGES, IMAGES } from "@/lib/data";

const FLOORS = ["G", "G+1", "G+2", "G+3", "Duplex"];

export default function Estimator({ onLockEstimate }) {
  const [area, setArea] = useState(1800);
  const [pkgId, setPkgId] = useState("premium");
  const [floors, setFloors] = useState("G+1");

  const pkg = PACKAGES.find((p) => p.id === pkgId);
  const total = useMemo(() => area * pkg.rate, [area, pkg]);
  const months = useMemo(
    () => Math.min(24, Math.round(5 + area / 450 + FLOORS.indexOf(floors))),
    [area, floors]
  );
  const fill = ((area - 800) / (12000 - 800)) * 100;

  return (
    <section id="estimator" className="relative py-24 sm:py-32 overflow-hidden">
      <div className="absolute inset-0 z-0">
        <img src={IMAGES.skeleton} alt="" className="w-full h-full object-cover opacity-15" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#07080A] via-[#07080A]/85 to-[#07080A]" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-5 sm:px-8 grid gap-12 lg:grid-cols-2 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <p className="font-jbmono text-xs uppercase tracking-[0.35em] text-amber-400">
            Cost Estimator
          </p>
          <h2 className="mt-3 font-syne font-extrabold uppercase tracking-tight text-3xl sm:text-5xl text-white">
            Know Your Investment
            <span className="block text-zinc-500">Before We Break Ground.</span>
          </h2>
          <p className="mt-4 text-zinc-400 text-base sm:text-lg max-w-lg">
            Slide, select, and see a transparent figure instantly — every estimate is inclusive
            of GST and honourable at the negotiating table.
          </p>

          <div className="mt-10 space-y-8">
            <div>
              <div className="flex justify-between font-jbmono text-xs uppercase tracking-[0.2em] text-zinc-400">
                <span>Built-up Area</span>
                <span className="text-amber-400">{area.toLocaleString("en-IN")} sq.ft</span>
              </div>
              <input
                type="range"
                min={800}
                max={12000}
                step={50}
                value={area}
                onChange={(e) => setArea(Number(e.target.value))}
                style={{ "--fill": `${fill}%` }}
                data-testid="estimator-area-slider"
                className="estimator-range mt-3 w-full"
              />
              <div className="flex justify-between font-jbmono text-[10px] text-zinc-600 mt-1.5">
                <span>800</span>
                <span>12,000</span>
              </div>
            </div>

            <div>
              <p className="font-jbmono text-xs uppercase tracking-[0.2em] text-zinc-400 mb-3">Package</p>
              <div className="grid grid-cols-3 gap-2" data-testid="estimator-package-select">
                {PACKAGES.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setPkgId(p.id)}
                    data-testid={`estimator-pkg-${p.id}`}
                    className={`rounded-md border px-3 py-3 text-sm font-syne font-bold uppercase transition-all duration-300 ${
                      pkgId === p.id
                        ? "border-amber-400 bg-amber-400/10 text-amber-400 shadow-[0_0_18px_rgba(245,158,11,0.25)]"
                        : "border-white/15 text-zinc-400 hover:border-amber-400/40"
                    }`}
                  >
                    {p.name}
                    <span className="block font-jbmono text-[10px] font-normal text-zinc-500">
                      ₹{p.rate}/sq.ft
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="font-jbmono text-xs uppercase tracking-[0.2em] text-zinc-400 mb-3">Floors</p>
              <div className="flex flex-wrap gap-2" data-testid="estimator-floors-select">
                {FLOORS.map((f) => (
                  <button
                    key={f}
                    onClick={() => setFloors(f)}
                    data-testid={`estimator-floor-${f.replace("+", "p")}`}
                    className={`rounded-full border px-4 py-2 text-xs font-jbmono uppercase tracking-wider transition-all duration-300 ${
                      floors === f
                        ? "border-amber-400 bg-amber-400/10 text-amber-400"
                        : "border-white/15 text-zinc-400 hover:border-amber-400/40"
                    }`}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.15 }}
          className="rounded-xl border border-amber-400/30 bg-[#0D0F14]/90 backdrop-blur p-8 sm:p-10 shadow-[0_0_60px_rgba(245,158,11,0.12)]"
        >
          <p className="font-jbmono text-xs uppercase tracking-[0.3em] text-zinc-400">
            Estimated Project Value
          </p>
          <div
            data-testid="estimator-total-price-display"
            className="mt-4 font-syne font-extrabold text-4xl sm:text-6xl text-white gold-glow"
          >
            ₹{total.toLocaleString("en-IN")}
          </div>
          <p className="mt-2 inline-flex items-center gap-1.5 text-xs font-jbmono uppercase tracking-[0.15em] text-emerald-400">
            <IndianRupee size={12} /> GST fully included — no surprises
          </p>

          <div className="mt-8 grid grid-cols-2 gap-4">
            <div className="rounded-lg border border-white/10 p-4">
              <p className="font-jbmono text-[10px] uppercase tracking-[0.2em] text-zinc-500">Rate Applied</p>
              <p className="mt-1 font-syne font-bold text-lg text-amber-400">
                ₹{pkg.rate.toLocaleString("en-IN")} / sq.ft
              </p>
            </div>
            <div className="rounded-lg border border-white/10 p-4">
              <p className="font-jbmono text-[10px] uppercase tracking-[0.2em] text-zinc-500">Est. Timeline</p>
              <p className="mt-1 font-syne font-bold text-lg text-white inline-flex items-center gap-2">
                <Clock size={16} className="text-amber-400" /> ~{months} months
              </p>
            </div>
          </div>

          <button
            onClick={() =>
              onLockEstimate({ package: pkg.id, area, total, floors })
            }
            data-testid="estimator-submit-btn"
            className="mt-8 w-full inline-flex items-center justify-center gap-2.5 bg-amber-400 text-black font-syne font-bold uppercase tracking-wide text-sm py-4 rounded-md hover:shadow-[0_0_35px_rgba(245,158,11,0.55)] hover:-translate-y-0.5 transition-all duration-300"
          >
            <Lock size={16} /> Lock Estimate & Request Site Visit
          </button>
        </motion.div>
      </div>
    </section>
  );
}
