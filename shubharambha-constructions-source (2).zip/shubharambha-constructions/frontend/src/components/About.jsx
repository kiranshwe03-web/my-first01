import { motion } from "framer-motion";
import { MANIFESTO, IMAGES } from "@/lib/data";

export default function About() {
  return (
    <section id="about" className="relative py-24 sm:py-32 bg-[#0A0C10] overflow-hidden">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 grid gap-14 lg:grid-cols-2">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          <div className="relative overflow-hidden rounded-xl border border-white/10">
            <img
              src={IMAGES.rebar}
              alt="Reinforced steel structure at a Shubharambha site"
              className="w-full h-[420px] sm:h-[540px] object-cover"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6">
              <p className="font-jbmono text-[10px] uppercase tracking-[0.3em] text-amber-400">
                The Shubharambha Standard
              </p>
              <p className="mt-1 font-syne font-bold text-xl text-white">
                Engineered in Mysore. Built for Generations.
              </p>
            </div>
          </div>
          <div className="absolute -top-4 -right-4 hidden sm:block rounded-lg border border-amber-400/40 bg-black/70 backdrop-blur px-5 py-3">
            <p className="font-syne font-extrabold text-2xl text-amber-400">0%</p>
            <p className="font-jbmono text-[10px] uppercase tracking-[0.2em] text-zinc-400">
              Compromise on Grade
            </p>
          </div>
        </motion.div>

        <div>
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <p className="font-jbmono text-xs uppercase tracking-[0.35em] text-amber-400">
              Our Agenda & Promises
            </p>
            <h2 className="mt-3 font-syne font-extrabold uppercase tracking-tight text-3xl sm:text-5xl text-white">
              A Manifesto Written
              <span className="block text-zinc-500">in Steel & Concrete.</span>
            </h2>
            <p className="mt-4 text-zinc-400 text-base sm:text-lg">
              Shubharambha was founded on a simple conviction — a Mysore family should never
              have to wonder what is inside their walls. These six promises govern every site
              we run, every slab we cast, every key we hand over.
            </p>
          </motion.div>

          <div className="mt-10 space-y-0 divide-y divide-white/10 border-y border-white/10">
            {MANIFESTO.map((m, i) => (
              <motion.div
                key={m.n}
                initial={{ opacity: 0, x: 40 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.6, delay: i * 0.07 }}
                className="group flex gap-5 py-5 hover:bg-amber-400/5 px-3 -mx-3 rounded transition-colors duration-300"
              >
                <span className="font-jbmono text-amber-400 text-sm pt-1">{m.n}</span>
                <div>
                  <h3 className="font-syne font-bold text-lg text-white group-hover:text-amber-400 transition-colors duration-300">
                    {m.title}
                  </h3>
                  <p className="text-sm text-zinc-400 mt-0.5">{m.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
