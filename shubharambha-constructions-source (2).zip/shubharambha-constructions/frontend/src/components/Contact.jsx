import { motion } from "framer-motion";
import {
  MapPin, Phone, Mail, Globe, Instagram, Facebook, Youtube, MessageCircle, ArrowUpRight,
} from "lucide-react";
import { CONTACT } from "@/lib/data";

const SOCIALS = [
  { id: "instagram", icon: Instagram, label: "Instagram", href: "https://instagram.com" },
  { id: "facebook", icon: Facebook, label: "Facebook", href: "https://facebook.com" },
  { id: "whatsapp", icon: MessageCircle, label: "WhatsApp", href: `https://wa.me/91${CONTACT.phones[0]}` },
  { id: "youtube", icon: Youtube, label: "YouTube", href: "https://youtube.com" },
];

export default function Contact() {
  return (
    <section id="contact" className="relative py-24 sm:py-32">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <p className="font-jbmono text-xs uppercase tracking-[0.35em] text-amber-400">
            Reach the Builders
          </p>
          <h2 className="mt-3 font-syne font-extrabold uppercase tracking-tight text-3xl sm:text-5xl text-white">
            Visit Our Mysore HQ.
            <span className="block text-zinc-500">Or Call — We Answer.</span>
          </h2>
        </motion.div>

        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <motion.a
            href={CONTACT.mapsUrl}
            target="_blank"
            rel="noreferrer"
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            data-testid="contact-address-card"
            className="group rounded-xl border border-white/10 bg-[#0D0F14] p-7 hover:border-amber-400/50 hover:shadow-[0_0_35px_rgba(245,158,11,0.15)] transition-all duration-500"
          >
            <MapPin size={26} className="text-amber-400" />
            <h3 className="mt-4 font-syne font-bold text-lg text-white">Head Office</h3>
            <p className="mt-2 text-sm text-zinc-400 leading-relaxed">{CONTACT.address}</p>
            <span className="mt-4 inline-flex items-center gap-1.5 font-jbmono text-[11px] uppercase tracking-[0.2em] text-amber-400/80 group-hover:text-amber-400">
              Open in Maps <ArrowUpRight size={13} />
            </span>
          </motion.a>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="rounded-xl border border-white/10 bg-[#0D0F14] p-7 hover:border-amber-400/50 hover:shadow-[0_0_35px_rgba(245,158,11,0.15)] transition-all duration-500"
          >
            <Phone size={26} className="text-amber-400" />
            <h3 className="mt-4 font-syne font-bold text-lg text-white">Call Us Directly</h3>
            <div className="mt-2 space-y-2">
              {CONTACT.phones.map((p, i) => (
                <a
                  key={p}
                  href={`tel:+91${p}`}
                  data-testid={i === 0 ? "contact-phone-primary" : "contact-phone-secondary"}
                  className="block text-sm text-zinc-300 hover:text-amber-400 transition-colors"
                >
                  +91 {p.slice(0, 5)} {p.slice(5)}
                </a>
              ))}
            </div>
            <p className="mt-4 font-jbmono text-[11px] uppercase tracking-[0.2em] text-zinc-500">
              Mon–Sat · 9 AM – 7 PM
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="rounded-xl border border-white/10 bg-[#0D0F14] p-7 hover:border-amber-400/50 hover:shadow-[0_0_35px_rgba(245,158,11,0.15)] transition-all duration-500"
          >
            <Mail size={26} className="text-amber-400" />
            <h3 className="mt-4 font-syne font-bold text-lg text-white">Write to Us</h3>
            <a
              href={`mailto:${CONTACT.email}`}
              data-testid="contact-email-link"
              className="mt-2 block text-sm text-zinc-300 hover:text-amber-400 transition-colors break-all"
            >
              {CONTACT.email}
            </a>
            <div className="mt-4 flex items-center gap-2 text-sm text-zinc-400">
              <Globe size={14} className="text-amber-400/70" />
              <a
                href={`https://${CONTACT.website}`}
                data-testid="contact-website-link"
                className="hover:text-amber-400 transition-colors"
              >
                {CONTACT.website}
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="rounded-xl border border-white/10 bg-[#0D0F14] p-7 hover:border-amber-400/50 hover:shadow-[0_0_35px_rgba(245,158,11,0.15)] transition-all duration-500"
          >
            <MessageCircle size={26} className="text-amber-400" />
            <h3 className="mt-4 font-syne font-bold text-lg text-white">Follow the Build</h3>
            <p className="mt-2 text-sm text-zinc-400">Site reels, walkthroughs & handovers.</p>
            <div className="mt-4 flex gap-3">
              {SOCIALS.map((s) => (
                <a
                  key={s.id}
                  href={s.href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={s.label}
                  data-testid={`contact-social-${s.id}`}
                  className="grid place-items-center w-10 h-10 rounded-md border border-white/15 text-zinc-300 hover:text-black hover:bg-amber-400 hover:border-amber-400 hover:shadow-[0_0_20px_rgba(245,158,11,0.5)] transition-all duration-300"
                >
                  <s.icon size={17} />
                </a>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-white/10 bg-black/60">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-10 flex flex-col sm:flex-row items-center justify-between gap-4">
        <p className="font-syne font-bold uppercase tracking-tight text-white">
          Shubharambha <span className="text-amber-400">Constructions</span>
        </p>
        <p className="font-jbmono text-[11px] uppercase tracking-[0.25em] text-zinc-500 text-center">
          Quality you can see — Trust you can feel
        </p>
        <p className="font-jbmono text-[11px] text-zinc-600">
          © {new Date().getFullYear()} {CONTACT.website}
        </p>
      </div>
    </footer>
  );
}
