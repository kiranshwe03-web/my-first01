import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { HardHat, MessageCircle, Lock } from "lucide-react";
import { CONTACT } from "@/lib/data";

const LINKS = [
  { id: "packages", label: "Packages" },
  { id: "services", label: "Services" },
  { id: "estimator", label: "Estimator" },
  { id: "about", label: "About" },
  { id: "reviews", label: "Reviews" },
  { id: "contact", label: "Contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-colors duration-500 ${
        scrolled
          ? "bg-black/80 backdrop-blur-xl border-b border-white/10"
          : "bg-transparent"
      }`}
    >
      <nav className="max-w-7xl mx-auto flex items-center justify-between px-5 sm:px-8 h-16">
        <a href="#top" data-testid="nav-brand-logo" className="flex items-center gap-2.5 group">
          <span className="w-9 h-9 grid place-items-center rounded-md bg-amber-400 text-black group-hover:shadow-[0_0_20px_rgba(245,158,11,0.6)] transition-shadow duration-300">
            <HardHat size={20} strokeWidth={2.2} />
          </span>
          <span className="font-syne font-bold tracking-tight text-sm sm:text-base uppercase">
            Shubharambha
            <span className="block text-[10px] font-jbmono tracking-[0.3em] text-amber-400/80">
              Constructions
            </span>
          </span>
        </a>

        <div className="hidden lg:flex items-center gap-7">
          {LINKS.map((l) => (
            <a
              key={l.id}
              href={`#${l.id}`}
              data-testid={`nav-link-${l.id}`}
              className="text-xs font-jbmono uppercase tracking-[0.2em] text-zinc-400 hover:text-amber-400 transition-colors duration-300"
            >
              {l.label}
            </a>
          ))}
        </div>

        <div className="flex items-center gap-3">
          <a
            href={`https://wa.me/91${CONTACT.phones[0]}`}
            target="_blank"
            rel="noreferrer"
            data-testid="nav-whatsapp-btn"
            className="hidden sm:flex items-center gap-2 text-xs font-jbmono uppercase tracking-wider text-emerald-400 border border-emerald-400/30 rounded-full px-4 py-2 hover:bg-emerald-400/10 transition-colors duration-300"
          >
            <MessageCircle size={14} /> WhatsApp
          </a>
          <Link
            to="/admin/login"
            data-testid="nav-link-admin"
            className="flex items-center gap-1.5 text-xs font-jbmono uppercase tracking-wider text-zinc-400 border border-white/15 rounded-full px-4 py-2 hover:text-amber-400 hover:border-amber-400/40 transition-colors duration-300"
          >
            <Lock size={12} /> Admin
          </Link>
        </div>
      </nav>
    </header>
  );
}
