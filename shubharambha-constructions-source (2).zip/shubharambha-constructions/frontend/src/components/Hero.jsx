import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Calculator, ClipboardList, MapPin } from "lucide-react";
import { IMAGES } from "@/lib/data";

const EASE = [0.22, 1, 0.36, 1];

function MaskedLine({ children, delay, className }) {
  return (
    <span className="block overflow-hidden pb-1">
      <motion.span
        initial={{ y: "115%" }}
        animate={{ y: "0%" }}
        transition={{ duration: 1, delay, ease: EASE }}
        className={`block ${className || ""}`}
      >
        {children}
      </motion.span>
    </span>
  );
}

function BrandName() {
  const word = "SHUBHARAMBHA";
  return (
    <h1
      data-testid="hero-brand-name"
      className="font-syne font-extrabold uppercase leading-[0.95] tracking-tight text-white"
    >
      <span className="block overflow-hidden text-[min(6vw,5.2rem)] whitespace-nowrap">
        <span className="flex">
          {word.split("").map((c, i) => (
            <motion.span
              key={i}
              initial={{ y: "110%", rotate: 4 }}
              animate={{ y: "0%", rotate: 0 }}
              transition={{ duration: 0.8, delay: 0.15 + i * 0.045, ease: EASE }}
              className="inline-block gold-glow"
            >
              {c}
            </motion.span>
          ))}
        </span>
      </span>
      <span className="block overflow-hidden text-[6vw] sm:text-[5vw] lg:text-[2.9rem]">
        <motion.span
          initial={{ y: "110%" }}
          animate={{ y: "0%" }}
          transition={{ duration: 0.9, delay: 0.75, ease: EASE }}
          className="block text-outline"
        >
          CONSTRUCTIONS
        </motion.span>
      </span>
    </h1>
  );
}

export default function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "28%"]);
  const bgScale = useTransform(scrollYProgress, [0, 1], [1.05, 1.2]);
  const fade = useTransform(scrollYProgress, [0, 0.75], [1, 0]);

  return (
    <section id="top" ref={ref} className="relative min-h-screen overflow-hidden flex flex-col">
      <motion.div style={{ y: bgY, scale: bgScale }} className="absolute inset-0 z-0">
        <img
          src={IMAGES.heroVilla}
          alt="Completed luxury villa by Shubharambha Constructions"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#07080A]/80 via-[#07080A]/55 to-[#07080A]" />
        <div className="absolute inset-0 blueprint-grid opacity-60" />
      </motion.div>

      <motion.div
        style={{ opacity: fade }}
        className="relative z-10 flex-1 flex flex-col justify-center max-w-7xl mx-auto w-full px-5 sm:px-8 pt-28 pb-16"
      >
        <MaskedLine delay={0.05}>
          <span className="inline-flex items-center gap-2 font-jbmono text-[11px] sm:text-xs tracking-[0.35em] uppercase text-amber-400/90">
            <MapPin size={13} /> Mysore · Karnataka · Residential — Commercial — Villas — Turnkey
          </span>
        </MaskedLine>

        <div className="mt-6">
          <BrandName />
        </div>

        <div className="mt-8 max-w-4xl">
          <MaskedLine delay={1.0} className="font-syne font-bold text-3xl sm:text-5xl lg:text-6xl leading-[1.08] tracking-tight">
            We Build <span className="text-amber-400">Landmarks</span>
          </MaskedLine>
          <MaskedLine delay={1.15} className="font-syne font-bold text-3xl sm:text-5xl lg:text-6xl leading-[1.08] tracking-tight text-zinc-300">
            That Outlive Generations.
          </MaskedLine>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 1.5, ease: EASE }}
          className="mt-10 flex flex-wrap items-center gap-4"
        >
          <a
            href="#estimator"
            data-testid="hero-cta-calculate"
            className="group inline-flex items-center gap-2.5 bg-amber-400 text-black font-syne font-bold uppercase tracking-wide text-sm px-7 py-4 rounded-md hover:shadow-[0_0_35px_rgba(245,158,11,0.55)] hover:-translate-y-0.5 transition-all duration-300"
          >
            <Calculator size={18} /> Estimate My Cost
          </a>
          <a
            href="#enquire"
            data-testid="hero-cta-enquire"
            className="inline-flex items-center gap-2.5 border border-white/25 text-white font-syne font-bold uppercase tracking-wide text-sm px-7 py-4 rounded-md hover:border-amber-400/60 hover:text-amber-400 hover:-translate-y-0.5 transition-all duration-300"
          >
            <ClipboardList size={18} /> Request Site Visit
          </a>
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.9, duration: 1 }}
        className="relative z-10 border-t border-white/10 bg-black/50 backdrop-blur-sm"
      >
        <div className="max-w-7xl mx-auto px-5 sm:px-8 grid grid-cols-3 divide-x divide-white/10">
          {[
            ["100%", "GST-Inclusive Pricing"],
            ["M-25", "Grade Concrete Standard"],
            ["Mysuru", "Headquartered & Trusted"],
          ].map(([v, l]) => (
            <div key={l} className="py-5 px-3 text-center">
              <div className="font-syne font-extrabold text-xl sm:text-2xl text-amber-400">{v}</div>
              <div className="font-jbmono text-[10px] sm:text-xs uppercase tracking-[0.2em] text-zinc-400 mt-1">{l}</div>
            </div>
          ))}
        </div>
      </motion.div>
    </section>
  );
}
