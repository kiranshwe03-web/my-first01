import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Send, Loader2, ClipboardCheck } from "lucide-react";
import { toast } from "sonner";
import api, { formatApiError } from "@/lib/api";
import { PACKAGES } from "@/lib/data";

const PROJECT_TYPES = ["Residential Home", "Commercial", "Villa", "Turnkey Project"];
const PLOT_SIZES = ["20x30", "30x40", "30x50", "40x60", "50x80", "Odd / Custom Size"];
const TIMELINES = ["Immediately", "Within 3 months", "3–6 months", "6–12 months", "Just exploring"];
const SITE_STATUSES = ["Plot already purchased", "Plot shortlisted", "Yet to buy a plot", "Old house — demolition & rebuild"];
const BUDGETS = ["Under ₹30 Lakh", "₹30–50 Lakh", "₹50–80 Lakh", "₹80 Lakh – ₹1.5 Cr", "Above ₹1.5 Cr"];

const EMPTY = {
  name: "",
  phone: "",
  email: "",
  project_type: "Residential Home",
  plot_location: "",
  plot_size: "",
  built_up_area: "",
  package: "premium",
  timeline: "",
  site_status: "",
  budget: "",
  requirements: "",
  estimated_cost: "",
};

const inputCls =
  "w-full bg-[#10131A] border border-white/10 rounded-md px-4 py-3 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400/60 focus:ring-1 focus:ring-amber-400/40 transition-all duration-300";

const labelCls = "block font-jbmono text-[11px] uppercase tracking-[0.2em] text-zinc-400 mb-2";

function Field({ label, children, required }) {
  return (
    <div>
      <label className={labelCls}>
        {label} {required && <span className="text-amber-400">*</span>}
      </label>
      {children}
    </div>
  );
}

export default function EnquiryForm({ prefill }) {
  const [form, setForm] = useState(EMPTY);
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (!prefill) return;
    setForm((f) => ({
      ...f,
      package: prefill.package || f.package,
      built_up_area: prefill.area || f.built_up_area,
      estimated_cost: prefill.total || f.estimated_cost,
    }));
  }, [prefill]);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) {
      toast.error("Please share at least your name and phone number.");
      return;
    }
    setSending(true);
    try {
      const pkgName = PACKAGES.find((p) => p.id === form.package)?.name || form.package;
      await api.post("/enquiries", {
        ...form,
        package: pkgName,
        built_up_area: form.built_up_area ? Number(form.built_up_area) : null,
        estimated_cost: form.estimated_cost ? Number(form.estimated_cost) : null,
      });
      toast.success("Requirement received. Our site engineer will call you within 24 hours.");
      setForm(EMPTY);
    } catch (err) {
      toast.error(formatApiError(err));
    } finally {
      setSending(false);
    }
  };

  return (
    <section id="enquire" className="relative py-24 sm:py-32 bg-[#0A0C10]">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 grid gap-14 lg:grid-cols-5">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="lg:col-span-2"
        >
          <p className="font-jbmono text-xs uppercase tracking-[0.35em] text-amber-400">
            Client Requirement Engine
          </p>
          <h2 className="mt-3 font-syne font-extrabold uppercase tracking-tight text-3xl sm:text-5xl text-white">
            Tell Us About
            <span className="block text-zinc-500">Your Dream Structure.</span>
          </h2>
          <p className="mt-4 text-zinc-400 text-base sm:text-lg">
            The more detail you share, the sharper our estimate. Every submission lands directly
            on our command desk and is answered by a real site engineer — not a bot.
          </p>

          <div className="mt-10 space-y-4">
            {[
              "Response within 24 working hours",
              "Free site visit & soil assessment across Mysore",
              "Itemised BOQ shared before any commitment",
            ].map((t) => (
              <div key={t} className="flex items-center gap-3 text-sm text-zinc-300">
                <span className="grid place-items-center w-7 h-7 rounded-md bg-amber-400/15 text-amber-400">
                  <ClipboardCheck size={15} />
                </span>
                {t}
              </div>
            ))}
          </div>
        </motion.div>

        <motion.form
          onSubmit={submit}
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.15 }}
          data-testid="enquiry-form"
          className="lg:col-span-3 rounded-xl border border-white/10 bg-[#0D0F14] p-7 sm:p-10"
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <Field label="Full Name" required>
              <input data-testid="enquiry-name-input" className={inputCls} placeholder="e.g. Suresh Kumar" value={form.name} onChange={set("name")} />
            </Field>
            <Field label="Phone (+91)" required>
              <input data-testid="enquiry-phone-input" className={inputCls} placeholder="10-digit mobile" value={form.phone} onChange={set("phone")} />
            </Field>
            <Field label="Email">
              <input data-testid="enquiry-email-input" type="email" className={inputCls} placeholder="you@example.com" value={form.email} onChange={set("email")} />
            </Field>
            <Field label="Project Type">
              <select data-testid="enquiry-project-type-select" className={inputCls} value={form.project_type} onChange={set("project_type")}>
                {PROJECT_TYPES.map((t) => <option key={t}>{t}</option>)}
              </select>
            </Field>
            <Field label="Plot Location in Mysore">
              <input data-testid="enquiry-location-input" className={inputCls} placeholder="e.g. Dattagalli, near Ring Road" value={form.plot_location} onChange={set("plot_location")} />
            </Field>
            <Field label="Plot Dimensions">
              <select data-testid="enquiry-plotsize-select" className={inputCls} value={form.plot_size} onChange={set("plot_size")}>
                <option value="">Select size</option>
                {PLOT_SIZES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Built-up Area (sq.ft)">
              <input data-testid="enquiry-area-input" type="number" min="0" className={inputCls} placeholder="e.g. 2400" value={form.built_up_area} onChange={set("built_up_area")} />
            </Field>
            <Field label="Preferred Package">
              <select data-testid="enquiry-package-select" className={inputCls} value={form.package} onChange={set("package")}>
                {PACKAGES.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} — ₹{p.rate}/sq.ft (incl. GST)
                  </option>
                ))}
                <option value="guidance">Need guidance choosing</option>
              </select>
            </Field>
            <Field label="When Do You Want to Start?">
              <select data-testid="enquiry-timeline-select" className={inputCls} value={form.timeline} onChange={set("timeline")}>
                <option value="">Select timeline</option>
                {TIMELINES.map((t) => <option key={t}>{t}</option>)}
              </select>
            </Field>
            <Field label="Site / Plot Status">
              <select data-testid="enquiry-site-status-select" className={inputCls} value={form.site_status} onChange={set("site_status")}>
                <option value="">Select status</option>
                {SITE_STATUSES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </Field>
            <Field label="Budget Range">
              <select data-testid="enquiry-budget-select" className={inputCls} value={form.budget} onChange={set("budget")}>
                <option value="">Select budget</option>
                {BUDGETS.map((b) => <option key={b}>{b}</option>)}
              </select>
            </Field>
            <Field label="Estimated Value (from calculator)">
              <input data-testid="enquiry-estimated-cost-input" className={inputCls} value={form.estimated_cost ? `₹${Number(form.estimated_cost).toLocaleString("en-IN")}` : ""} readOnly placeholder="Auto-filled by estimator" />
            </Field>
          </div>

          <div className="mt-5">
            <Field label="Special Structural Requirements">
              <textarea
                data-testid="enquiry-requirements-input"
                rows={4}
                className={inputCls}
                placeholder="Basement, rainwater harvesting, solar-ready terrace, vastu alignment, rental unit on top floor…"
                value={form.requirements}
                onChange={set("requirements")}
              />
            </Field>
          </div>

          <button
            type="submit"
            disabled={sending}
            data-testid="enquiry-submit-btn"
            className="mt-8 w-full inline-flex items-center justify-center gap-2.5 bg-amber-400 text-black font-syne font-bold uppercase tracking-wide text-sm py-4 rounded-md hover:shadow-[0_0_35px_rgba(245,158,11,0.55)] hover:-translate-y-0.5 transition-all duration-300 disabled:opacity-60 disabled:hover:translate-y-0"
          >
            {sending ? <Loader2 size={17} className="animate-spin" /> : <Send size={16} />}
            {sending ? "Submitting…" : "Submit Requirement to Our Engineers"}
          </button>
        </motion.form>
      </div>
    </section>
  );
}
