import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { Check, BadgePercent, ArrowRight } from "lucide-react";
import { PACKAGES } from "@/lib/data";

function SpotlightCard({ pkg, onSelect }) {
  const ref = useRef(null);
  const [pos, setPos] = useState({ x: -600, y: -600 });
  const [hover, setHover] = useState(false);

  const onMove = (e) => {
    const r = ref.current.getBoundingClientRect();
    setPos({ x: e.clientX - r.left, y: e.clientY - r.top });
  };

  return (
    <motion.div
      ref={ref}
      onMouseMove={onMove}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      initial={{ opacity: 0, y: 60 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
      data-testid={`package-card-${pkg.id}`}
      className={`relative overflow-hidden rounded-xl border bg-[#0D0F14] p-8 transition-colors duration-500 ${
        pkg.popular ? "border-amber-400/50" : "border-white/10"
      } ${hover ? "border-amber-400/60" : ""}`}
    >
      <div
        className="pointer-events-none absolute inset-0 transition-opacity duration-500"
        style={{
          opacity: hover ? 1 : 0,
          background: `radial-gradient(520px circle at ${pos.x}px ${pos.y}px, rgba(245,158,11,0.22), rgba(245,158,11,0.06) 45%, transparent 65%)`,
        }}
      />
      <div
        className="pointer-events-none absolute inset-0 rounded-xl transition-opacity duration-500"
        style={{
          opacity: hover ? 1 : 0,
          background: `radial-gradient(320px circle at ${pos.x}px ${pos.y}px, rgba(255,220,150,0.12), transparent 60%)`,
        }}
      />

      {pkg.popular && (
        <span className="absolute top-0 right-0 bg-amber-400 text-black font-jbmono text-[10px] font-bold uppercase tracking-[0.2em] px-4 py-1.5 rounded-bl-lg">
          Most Popular
        </span>
      )}

      <div className="relative z-10">
        <p className="font-jbmono text-xs uppercase tracking-[0.3em] text-amber-400/80">{pkg.tag}</p>
        <h3 className="mt-2 font-syne font-extrabold text-2xl sm:text-3xl uppercase text-white">
          {pkg.name}
        </h3>

        <div className="mt-5 flex items-end gap-2">
          <span className="font-syne font-extrabold text-4xl sm:text-5xl text-white">
            ₹{pkg.rate.toLocaleString("en-IN")}
          </span>
          <span className="font-jbmono text-xs text-zinc-400 pb-1.5">/ sq.ft</span>
        </div>
        <p className="mt-1.5 inline-flex items-center gap-1.5 text-[11px] font-jbmono uppercase tracking-[0.15em] text-emerald-400">
          <BadgePercent size={13} /> Inclusive of GST
        </p>

        <ul className="mt-7 space-y-3.5">
          {pkg.features.map((f) => (
            <li key={f} className="flex items-start gap-3 text-sm text-zinc-300">
              <span className="mt-0.5 grid place-items-center w-5 h-5 rounded-full bg-amber-400/15 text-amber-400 shrink-0">
                <Check size={12} strokeWidth={3} />
              </span>
              {f}
            </li>
          ))}
        </ul>

        <button
          onClick={() => onSelect(pkg.id)}
          data-testid={`package-btn-select-${pkg.id}`}
          className={`mt-8 w-full inline-flex items-center justify-center gap-2 font-syne font-bold uppercase tracking-wide text-sm py-3.5 rounded-md transition-all duration-300 ${
            pkg.popular
              ? "bg-amber-400 text-black hover:shadow-[0_0_30px_rgba(245,158,11,0.55)]"
              : "border border-white/20 text-white hover:border-amber-400/60 hover:text-amber-400"
          }`}
        >
          Select This Package <ArrowRight size={16} />
        </button>
      </div>
    </motion.div>
  );
}

export default function Packages({ onSelect }) {
  return (
    <section id="packages" className="relative py-24 sm:py-32">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl"
        >
          <p className="font-jbmono text-xs uppercase tracking-[0.35em] text-amber-400">
            Construction Packages
          </p>
          <h2 className="mt-3 font-syne font-extrabold uppercase tracking-tight text-3xl sm:text-5xl text-white">
            Three Ways to Build.
            <span className="block text-zinc-500">One Standard of Excellence.</span>
          </h2>
          <p className="mt-4 text-zinc-400 text-base sm:text-lg">
            Every package is a complete structural specification — priced transparently per
            square foot, and every rate is <span className="text-amber-400">100% inclusive of GST</span>.
            Move your cursor across a card to see it come alive.
          </p>
        </motion.div>

        <div className="mt-14 grid gap-6 lg:grid-cols-3">
          {PACKAGES.map((pkg) => (
            <SpotlightCard key={pkg.id} pkg={pkg} onSelect={onSelect} />
          ))}
        </div>
      </div>
    </section>
  );
}
