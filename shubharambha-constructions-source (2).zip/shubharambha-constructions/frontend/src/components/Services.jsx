import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { SERVICES } from "@/lib/data";

export default function Services() {
  return (
    <section id="services" className="relative py-24 sm:py-32 bg-[#0A0C10]">
      <div className="max-w-7xl mx-auto px-5 sm:px-8">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="flex flex-wrap items-end justify-between gap-6"
        >
          <div className="max-w-2xl">
            <p className="font-jbmono text-xs uppercase tracking-[0.35em] text-amber-400">
              What We Build
            </p>
            <h2 className="mt-3 font-syne font-extrabold uppercase tracking-tight text-3xl sm:text-5xl text-white">
              Four Disciplines.<span className="block text-zinc-500">One Obsession: Structure.</span>
            </h2>
          </div>
          <p className="max-w-sm text-zinc-400 text-sm sm:text-base">
            We take on only what we can engineer flawlessly — residential homes, commercial
            landmarks, bespoke villas and complete turnkey contracts.
          </p>
        </motion.div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2">
          {SERVICES.map((s, i) => (
            <motion.a
              key={s.id}
              href="#enquire"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.7, delay: (i % 2) * 0.12 }}
              data-testid={`service-card-${s.id}`}
              className="group relative overflow-hidden rounded-xl border border-white/10 h-72 sm:h-80 block"
            >
              <img
                src={s.image}
                alt={s.title}
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/10 group-hover:from-black/95 transition-colors duration-500" />
              <div className="absolute inset-x-0 bottom-0 p-6 sm:p-8">
                <div className="flex items-center justify-between">
                  <h3 className="font-syne font-extrabold uppercase text-xl sm:text-2xl text-white">
                    {s.title}
                  </h3>
                  <span className="grid place-items-center w-10 h-10 rounded-full border border-white/20 text-white group-hover:bg-amber-400 group-hover:text-black group-hover:border-amber-400 transition-all duration-300">
                    <ArrowUpRight size={18} />
                  </span>
                </div>
                <p className="mt-2 text-sm text-zinc-300 max-w-md opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500">
                  {s.desc}
                </p>
              </div>
              <span className="absolute top-5 left-5 font-jbmono text-xs text-amber-400/90 tracking-[0.25em]">
                0{i + 1}
              </span>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
