import { Sparkle } from "lucide-react";

export default function Marquee() {
  const phrase = "QUALITY YOU CAN SEE — TRUST YOU CAN FEEL";
  const items = Array(8).fill(phrase);
  return (
    <div
      data-testid="tagline-marquee"
      className="relative overflow-hidden border-y border-amber-400/25 bg-gradient-to-r from-amber-400/5 via-amber-400/10 to-amber-400/5 py-3.5"
    >
      <div className="flex w-max animate-marquee whitespace-nowrap">
        {[...items, ...items].map((t, i) => (
          <span
            key={i}
            className="mx-8 inline-flex items-center gap-8 font-jbmono text-xs sm:text-sm tracking-[0.35em] uppercase text-amber-400"
          >
            {t}
            <Sparkle size={13} className="text-amber-500/70" />
          </span>
        ))}
      </div>
    </div>
  );
}
