# PRD — Shubharambha Constructions Website

## Original Problem Statement
Build a modern, heavily animated, dark-theme website for "Shubharambha Constructions" (shubharambhaconstructions.co.in), Mysore. Showcase services (residential, commercial, villas, turnkey — no interior fit-outs), packages (Essential ₹1899, Premium ₹1999, Elite ₹2199 per sq.ft, all incl. GST), about/agenda/promises, Mysore client reviews, cost estimator, multi-field client requirement form, rich contact section (Near Christ Public School, Dattagalli, Mysore 570026; 9741958613 / 8747018061; info@shubharambhaconstructions.co.in; social icons). Backend: enquiries saved to database, notified in admin dashboard; admin login. Company name large & animated, scrolling tagline "Quality you can see • Trust you can feel", hero headline "We Build Landmarks That Outlive Generations", cursor spotlight glow on package cards, parallax construction imagery.

## Architecture
- Frontend: React 19 + Tailwind + framer-motion + lenis smooth scroll + sonner toasts. Routes: `/` landing, `/admin/login`, `/admin`.
- Backend: FastAPI, JWT admin auth (bcrypt hash, 12h token), enquiries CRUD + stats, admin seeded at startup from env.
- DB: MongoDB (MONGO_URL/DB_NAME from env). Collections: users (admin), enquiries.

## User Personas
- Prospective client: explores packages, estimates cost, submits requirement.
- Company admin: logs into /admin, views/manages enquiries, exports CSV.

## Implemented (2026-09-03)
- Kinetic hero: staggered letter reveal of SHUBHARAMBHA, outline "CONSTRUCTIONS", masked line-by-line headline, parallax villa background, blueprint grid, stats strip.
- Scrolling amber marquee: "Quality you can see — Trust you can feel".
- Packages: Essential ₹1,899 / Premium ₹1,999 / Elite ₹2,199 per sq.ft (all "Inclusive of GST"), exact spec lists from owner, cursor spotlight illumination, select → pre-fills enquiry form.
- Services grid: Residential, Commercial, Bespoke Villas, Turnkey (image cards, hover reveals). No interior fit-outs mentioned.
- Cost estimator: area slider (800–12,000 sq.ft), package & floor selectors, live ₹ total, timeline, "Lock estimate" → carries into enquiry form.
- About/Agenda: six-promise manifesto (BOQ transparency, grade-certified concrete, laser-leveled slabs, branded steel/cement, on-time handover, structural warranty).
- Reviews: 6 Mysore clients with localities (Vijayanagar, Kuvempunagar, Bogadi, Jayalakshmipuram, Dattagalli, Gokulam), residential/commercial/turnkey project tags only.
- Enquiry form: 13 fields (name, phone, email, project type, plot location, dimensions, built-up area, package, timeline, site status, budget, estimated value, requirements) → POST /api/enquiries → MongoDB.
- Contact: address + Google Maps link, tel: links both numbers, mailto, website, Instagram/Facebook/WhatsApp/YouTube icons (placeholder URLs).
- Admin: JWT login, dashboard with stats cards, "N new" notification badge, search, status filter, status update, delete, CSV export.

## Backlog
- P0: Email notification to company inbox on new enquiry (Resend managed integration — deferred per user choice).
- P1: Replace social icon placeholder URLs with real handles; Google Maps embed of Dattagalli office.
- P1: Point custom domain shubharambhaconstructions.co.in at deployment.
- P2: Project gallery page with real completed-site photos; WhatsApp auto-reply; enquiry email receipt to client.

## Next Tasks
1. Turn on email alerts via Resend (needs company mailbox decision).
2. Add real project photos/testimonial consent.
3. Domain + production deployment.
