# Test Credentials
# Agent writes here when creating/modifying auth credentials (admin accounts, test users).
# Testing agent reads this before auth tests. Fork/continuation agents read on startup.

## Admin Account (test credentials — reseed anytime via backend/.env)
- Email: admin@shubharambhaconstructions.co.in
- Password: Shubharambha@2026
- Role: admin
- Admin login URL: /admin/login
- Admin dashboard URL: /admin

## Auth Endpoints
- POST /api/auth/login  {email, password} -> {access_token, user}
- GET  /api/auth/me     (Bearer token)

## Protected Endpoints (Bearer token required)
- GET    /api/enquiries
- GET    /api/enquiries/stats
- PATCH  /api/enquiries/{id}  {status}
- DELETE /api/enquiries/{id}

## Public Endpoint
- POST /api/enquiries  (client enquiry form)
